<?php

namespace JoeDixon\Translation\Exceptions;

class LanguageExistsException extends \Exception
{
}
