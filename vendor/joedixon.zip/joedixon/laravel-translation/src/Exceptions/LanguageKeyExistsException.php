<?php

namespace JoeDixon\Translation\Exceptions;

class LanguageKeyExistsException extends \Exception
{
}
